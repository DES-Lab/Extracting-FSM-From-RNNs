[Link to the original repo](https://github.com/tech-srl/lstar_extraction)
